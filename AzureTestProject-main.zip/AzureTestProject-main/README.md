# Documentation

Full documentation is available at https://www.roundthecode.com/dotnet-samples/azure-devops-pipeline-sample-dotnet-project-ci-cd